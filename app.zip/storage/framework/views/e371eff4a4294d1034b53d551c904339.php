<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title"><i class="fa fa-user-injured"></i> Tambah Pasien Baru</h4>
        
            <form action="<?php echo e(route('admin.pasien.store')); ?>" method="post" class="form-group">
                <?php echo csrf_field(); ?>
                
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'name','label' => 'Nama Pasien','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'name','label' => 'Nama Pasien','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'no_rm','label' => 'Nomor RM','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'no_rm','label' => 'Nomor RM','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'tempat_lahir','label' => 'Tempat Lahir','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'tempat_lahir','label' => 'Tempat Lahir','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                        
                        <label for="gender">Jenis Kelamin*</label>
                        <select name="gender" id="gender" class="form-select" required onchange="formSuamiIstri()">
                            <option value="laki-laki">Laki-laki</option>
                            <option value="perempuan">Perempuan</option>
                        </select>

                        <label for="agama">Agama*</label>
                        <select name="agama" id="agama" class="form-select" required>
                            <option value="" selected disabled>--Pilih--</option>
                            <option value="islam">Islam</option>
                            <option value="kristen">Kristen</option>
                            <option value="khatolik">Khatolik</option>
                            <option value="hindu">Hindu</option>
                            <option value="budha">Budha</option>
                            <option value="konghucu">Konghucu</option>
                        </select>

                        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'no_hp','label' => 'No HP','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'no_hp','label' => 'No HP','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>

                        <label for="jenis_pembayaran">Cara Bayar*</label>
                        <select name="jenis_pembayaran" id="jenis_pembayaran" class="form-select" required>
                            <option value="" selected disabled>--Pilih--</option>
                            <option value="umum/mandiri">Umum/Mandiri</option>
                            <option value="jaminan kesehatan">Jaminan Kesehatan</option>
                        </select>

                        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'pekerjaan','label' => 'Pekerjaan','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'pekerjaan','label' => 'Pekerjaan','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                    </div>

                    <div class="col-md-6 col-lg-6 col-12">
                        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'no_bpjs','label' => 'No. BPJS/KTP','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'no_bpjs','label' => 'No. BPJS/KTP','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e(date('Y-m-d')).'','type' => 'date','name' => 'tanggal_lahir','label' => 'Tanggal Lahir','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(date('Y-m-d')).'','type' => 'date','name' => 'tanggal_lahir','label' => 'Tanggal Lahir','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                        
                        <label for="status_menikah">Status Menikah*</label>
                        <select name="status_menikah" id="status_menikah" class="form-select" required  onchange="formSuamiIstri()">
                            <option value="" selected disabled>--Pilih--</option>
                            <option value="belum menikah">Belum Menikah</option>
                            <option value="menikah">Menikah</option>
                            <option value="duda">Duda</option>
                            <option value="janda">Janda</option>
                        </select>

                        <label for="pendidikan">Pendidikan*</label>
                        <select name="pendidikan" id="pendidikan" class="form-select" required>
                            <option value="" selected disabled>--Pilih--</option>
                            <option value="SD">SD</option>
                            <option value="SMP/Sederajat">SMP/Sederajat</option>
                            <option value="SMA/Sederajat">SMA/Sederajat</option>
                            <option value="Diploma">Diploma</option>
                            <option value="S1/Sederajat">S1/Sederajat</option>
                            <option value="S2/Sederajat">S2/Sederajat</option>
                            <option value="S3/Sederajat">S3/Sederajat</option>
                            <option value="Tidak Sekolah">Tidak Sekolah</option>
                        </select>

                        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'email','name' => 'email','label' => 'Email (digunakan username dan password)','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'email','name' => 'email','label' => 'Email (digunakan username dan password)','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                        
                        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'alergi','label' => 'Alergi','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'alergi','label' => 'Alergi','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>

                        <label for="alamat">Alamat Lengkap</label>
                        <textarea name="alamat" id="alamat" class="form-control" cols="30" rows="5"></textarea>                        
                    </div>
                </div>
                <hr>
                <div class="suami-istri" style="display: none">
                    <h3 id="title">Data</h3>
                    <div class="row">
                        <div class="col-md-6 col-lg-6 col-12">
                            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'nama_ss','label' => 'Nama','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'nama_ss','label' => 'Nama','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'tempat_lahir_ss','label' => 'Tempat Lahir','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'tempat_lahir_ss','label' => 'Tempat Lahir','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e(date('Y-m-d')).'','type' => 'date','name' => 'tanggal_lahir_ss','label' => 'Tanggal Lahir','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(date('Y-m-d')).'','type' => 'date','name' => 'tanggal_lahir_ss','label' => 'Tanggal Lahir','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'pekerjaan_ss','label' => 'Pekerjaan','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'pekerjaan_ss','label' => 'Pekerjaan','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                            
                        </div>
                        
                        <div class="col-md-6 col-lg-6 col-12">
                            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'no_bpjs_ss','label' => 'No. BPJS/KTP','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'no_bpjs_ss','label' => 'No. BPJS/KTP','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'no_hp_ss','label' => 'No. HP','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'no_hp_ss','label' => 'No. HP','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                            
                            <label for="pendidikan">Pendidikan*</label>
                            <select name="pendidikan_ss" id="pendidikan" class="form-select">
                                <option value="" selected disabled>--Pilih--</option>
                                <option value="SD">SD</option>
                                <option value="SMP/Sederajat">SMP/Sederajat</option>
                                <option value="SMA/Sederajat">SMA/Sederajat</option>
                                <option value="Diploma">Diploma</option>
                                <option value="S1/Sederajat">S1/Sederajat</option>
                                <option value="S2/Sederajat">S2/Sederajat</option>
                                <option value="S3/Sederajat">S3/Sederajat</option>
                                <option value="Tidak Sekolah">Tidak Sekolah</option>
                            </select>
                        </div>
                    </div>

                    
                </div>
                <button class="btn btn-primary mt-3">SIMPAN</button>
            </form>
        </div>
    </div>

    <script>
        function formSuamiIstri(){
            const gender = $('#gender').val();
            const status_menikah = $('#status_menikah').val();

            let title = '';
            if(gender == 'laki-laki' && status_menikah == 'menikah'){
                title = 'Data Istri';
            } else if(gender == 'perempuan' && status_menikah == 'menikah'){
                title = 'Data Suami';
            }

            if(title){
                $('.suami-istri').show();
            } else{
                $('.suami-istri').hide();
            }
            // update text title
            $('#title').text(title)

        }
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/pasien/create.blade.php ENDPATH**/ ?>