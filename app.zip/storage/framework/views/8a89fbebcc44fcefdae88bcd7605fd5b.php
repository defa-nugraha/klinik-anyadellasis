<?php $__env->startSection('content'); ?>
    <div class="mb-3">
        <?php if (isset($component)) { $__componentOriginaleaeaaaad569af01bb3cb77043cbff144 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleaeaaaad569af01bb3cb77043cbff144 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tambah-data','data' => ['action' => ''.e(route('apotek.obat.create')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tambah-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('apotek.obat.create')).'']); ?>
            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'kode','label' => 'Kode Obat','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'kode','label' => 'Kode Obat','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'nama','label' => 'Nama Obat','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'nama','label' => 'Nama Obat','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'satuan','label' => 'Satuan','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'satuan','label' => 'Satuan','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'number','name' => 'stok','label' => 'Stok','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'stok','label' => 'Stok','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal1565b56a0536065e7a4d86ebdbcd1c6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1565b56a0536065e7a4d86ebdbcd1c6a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-rupiah','data' => ['type' => 'text','value' => '','name' => 'harga','label' => 'Harga','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-rupiah'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','value' => '','name' => 'harga','label' => 'Harga','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1565b56a0536065e7a4d86ebdbcd1c6a)): ?>
<?php $attributes = $__attributesOriginal1565b56a0536065e7a4d86ebdbcd1c6a; ?>
<?php unset($__attributesOriginal1565b56a0536065e7a4d86ebdbcd1c6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1565b56a0536065e7a4d86ebdbcd1c6a)): ?>
<?php $component = $__componentOriginal1565b56a0536065e7a4d86ebdbcd1c6a; ?>
<?php unset($__componentOriginal1565b56a0536065e7a4d86ebdbcd1c6a); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'bpjs','label' => 'Untk BPJS']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bpjs','label' => 'Untk BPJS']); ?>
                <option value="1">Ya</option>
                <option value="0">Tidak</option>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleaeaaaad569af01bb3cb77043cbff144)): ?>
<?php $attributes = $__attributesOriginaleaeaaaad569af01bb3cb77043cbff144; ?>
<?php unset($__attributesOriginaleaeaaaad569af01bb3cb77043cbff144); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleaeaaaad569af01bb3cb77043cbff144)): ?>
<?php $component = $__componentOriginaleaeaaaad569af01bb3cb77043cbff144; ?>
<?php unset($__componentOriginaleaeaaaad569af01bb3cb77043cbff144); ?>
<?php endif; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Data Obat']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Data Obat']); ?>
        <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <thead>
                <th>No</th>
                <th>Kode</th>
                <th>Obat</th>
                <th>Satuan</th>
                <th>Stok</th>
                <th>Harga</th>
                <th>Untuk BPJS</th>
                <th></th>
            </thead>

            <tbody>
                <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><span class="badge bg-warning"><?php echo e($o->kode); ?></span></td>
                        <td><?php echo e($o->nama); ?></td>
                        <td><?php echo e($o->satuan); ?></td>
                        <td><?php echo e($o->stok); ?></td>
                        <td><?php echo e(formatRupiah($o->harga)); ?></td>
                        <td><?php echo e(($o->bpjs) ? 'Ya':'Tidak'); ?></td>
                        <td>
                            <?php if (isset($component)) { $__componentOriginal52984d0dc87f31be3fd7055890be5eb4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52984d0dc87f31be3fd7055890be5eb4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.actions','data' => ['id' => ''.e($o->id).'','routeDelete' => ''.e(route('apotek.obat.delete', encryptStr($o->id))).'','routeEdit' => ''.e(route('apotek.obat.update')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => ''.e($o->id).'','routeDelete' => ''.e(route('apotek.obat.delete', encryptStr($o->id))).'','routeEdit' => ''.e(route('apotek.obat.update')).'']); ?>
                                <input type="hidden" name="id" value="<?php echo e(encryptStr($o->id)); ?>">
                                <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($o->kode).'','type' => 'text','name' => 'kode','label' => 'Kode Obat','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($o->kode).'','type' => 'text','name' => 'kode','label' => 'Kode Obat','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($o->nama).'','type' => 'text','name' => 'nama','label' => 'Nama Obat','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($o->nama).'','type' => 'text','name' => 'nama','label' => 'Nama Obat','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($o->satuan).'','type' => 'text','name' => 'satuan','label' => 'Satuan','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($o->satuan).'','type' => 'text','name' => 'satuan','label' => 'Satuan','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($o->stok).'','type' => 'number','name' => 'stok','label' => 'Stok','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($o->stok).'','type' => 'number','name' => 'stok','label' => 'Stok','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginal1565b56a0536065e7a4d86ebdbcd1c6a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1565b56a0536065e7a4d86ebdbcd1c6a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-rupiah','data' => ['type' => 'text','value' => ''.e(formatRupiah($o->harga, false)).'','name' => 'harga','label' => 'Harga','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-rupiah'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','value' => ''.e(formatRupiah($o->harga, false)).'','name' => 'harga','label' => 'Harga','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1565b56a0536065e7a4d86ebdbcd1c6a)): ?>
<?php $attributes = $__attributesOriginal1565b56a0536065e7a4d86ebdbcd1c6a; ?>
<?php unset($__attributesOriginal1565b56a0536065e7a4d86ebdbcd1c6a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1565b56a0536065e7a4d86ebdbcd1c6a)): ?>
<?php $component = $__componentOriginal1565b56a0536065e7a4d86ebdbcd1c6a; ?>
<?php unset($__componentOriginal1565b56a0536065e7a4d86ebdbcd1c6a); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'bpjs','label' => 'Untk BPJS']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'bpjs','label' => 'Untk BPJS']); ?>
                                    <option value="1" <?php echo e(($o->bpjs) ? 'selected' : ''); ?>>Ya</option>
                                    <option value="0" <?php echo e(($o->bpjs) ? '' : 'selected'); ?>>Tidak</option>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52984d0dc87f31be3fd7055890be5eb4)): ?>
<?php $attributes = $__attributesOriginal52984d0dc87f31be3fd7055890be5eb4; ?>
<?php unset($__attributesOriginal52984d0dc87f31be3fd7055890be5eb4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52984d0dc87f31be3fd7055890be5eb4)): ?>
<?php $component = $__componentOriginal52984d0dc87f31be3fd7055890be5eb4; ?>
<?php unset($__componentOriginal52984d0dc87f31be3fd7055890be5eb4); ?>
<?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.apotek', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/apotek/obat/index.blade.php ENDPATH**/ ?>