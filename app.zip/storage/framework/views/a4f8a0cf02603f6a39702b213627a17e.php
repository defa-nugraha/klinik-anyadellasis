<?php $__env->startSection('content'); ?>
<details class="mb-3">
    <summary>
        Tampilkan detail pasien
    </summary>
    <p>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h4 class="card-title">Detail Pasien</h4>
                            <span class="text-muted">RM# <?php echo e($pasien->no_rm); ?></span>
                        </div>
                        <hr>
                        
                        <!-- Responsive Grid -->
                        <div class="row">
                            <!-- Detail Pasien -->
                            <div class="col-md-4">
                                <h5><i class="fas fa-user"></i> Detail Pasien</h5>
                                <dl>
                                    <dt><i class="fas fa-user"></i> Nama</dt>
                                    <dd><?php echo e($pasien->user->name); ?>, <?php echo e($pasien->gender); ?> (<?php echo e($pasien->status_menikah); ?>)</dd>
                                    <dt><i class="fas fa-calendar-alt"></i> Tempat, Tanggal Lahir</dt>
                                    <dd><?php echo e($pasien->tempat_lahir); ?>, <?php echo e($pasien->tanggal_lahir); ?></dd>
                                    <dt><i class="fas fa-briefcase"></i> Pekerjaan, Pendidikan</dt>
                                    <dd><?php echo e($pasien->pekerjaan); ?>, <?php echo e($pasien->pendidikan); ?></dd>
                                    <dt><i class="fas fa-map-marker-alt"></i> Alamat</dt>
                                    <dd><?php echo e($pasien->alamat); ?></dd>
                                </dl>
                            </div>
                            
                            <!-- Info Pasien -->
                            <div class="col-md-4">
                                <h5><i class="fas fa-info-circle"></i> Info Pasien</h5>
                                <dl>
                                    <dt><i class="fas fa-phone-alt"></i> No HP</dt>
                                    <dd><?php echo e($pasien->no_hp); ?></dd>
                                    <dt><i class="fas fa-id-card"></i> No BPJS/KTP</dt>
                                    <dd><?php echo e($pasien->no_bpjs); ?></dd>
                                    <dt><i class="fas fa-credit-card"></i> Pembayaran</dt>
                                    <dd><?php echo e($pasien->jenis_pembayaran); ?></dd>
                                    <dt><i class="fas fa-exclamation-triangle"></i> Alergi</dt>
                                    <dd><?php echo e($pasien->alergi); ?></dd>
                                </dl>
                            </div>
        
                            <!-- Detail Suami/Istri (Jika Menikah) -->
                            <?php if($pasien->status_menikah == 'menikah'): ?>
                                <div class="col-md-4">
                                    <h5><i class="fas fa-heart"></i> Detail <?php echo e($pasien->gender == 'laki-laki' ? 'Istri' : 'Suami'); ?></h5>
                                    <dl>
                                        <dt><i class="fas fa-user"></i> Nama</dt>
                                        <dd><?php echo e($suamiIstri->nama); ?></dd>
                                        <dt><i class="fas fa-phone-alt"></i> No HP</dt>
                                        <dd><?php echo e($suamiIstri->no_hp); ?></dd>
                                        <dt><i class="fas fa-id-card"></i> No BPJS/KTP</dt>
                                        <dd><?php echo e($suamiIstri->no_bpjs); ?></dd>
                                        <dt><i class="fas fa-calendar-alt"></i> Tempat, Tanggal Lahir</dt>
                                        <dd><?php echo e($suamiIstri->tempat_lahir); ?>, <?php echo e($suamiIstri->tanggal_lahir); ?></dd>
                                        <dt><i class="fas fa-briefcase"></i> Pekerjaan, Pendidikan</dt>
                                        <dd><?php echo e($suamiIstri->pekerjaan); ?>, <?php echo e($suamiIstri->pendidikan); ?></dd>
                                    </dl>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <hr>
    </p>
</details>

<hr>

<div class="row">
    <div class="col-md-12 col-lg-12 col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">
                    <i class="ti ti-stethoscope fs-6"></i> Rekam Medis Pasien
                </h4>

                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <ul>
                            <li>
                                <Strong>Tanggal Pemeriksaan: </Strong>
                                <p>
                                    <?php echo e($rekamMedis->tgl_pemeriksaan); ?>

                                </p>
                            </li>
                            <li>
                                <Strong>Riwayat Persalinan: </Strong>
                                <p>
                                    <?php if($rekamMedis->id_rm_kandungan): ?>
                                    G: <?php echo e($rekamMedis->riwayat_persalinan->g); ?> P: <?php echo e($rekamMedis->riwayat_persalinan->p); ?> A: <?php echo e($rekamMedis->riwayat_persalinan->a); ?>

                                    <?php else: ?> 
                                        -
                                    <?php endif; ?>
                                </p>
                            </li>
                            <li>
                                <strong>Ammanesia: </strong> 
                                <p>
                                    <?php echo e($rekamMedis->ammanesia); ?>

                                </p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-lg-6 col-12">
                        <ul>
                            <li>
                                <strong>Pemeriksaan: </strong> <?php echo ($rekamMedis->id_pemeriksaan) ? $rekamMedis->pemeriksaan->deskripsi : '-'; ?>

                            </li>
                            <li>
                                <strong>Diagnosa: </strong> <?php echo ($rekamMedis->id_diagnosa) ? $rekamMedis->diagnosa->deskripsi : '-'; ?>

                            </li>
                            <li>
                                <strong>Tindakan: </strong> <?php echo ($rekamMedis->id_tindakan) ? $rekamMedis->tindakan->deskripsi : '-'; ?>

                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-4 col-lg-4 col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><i class="fa fa-pills"></i> Pemberian Obat</h4>

                <form action="" method="post">
                    <input type="hidden" name="id_obat" id="id_obat">
                    <input type="hidden" name="kode" id="kode">
                    <label for="obat" class="form-label">Nama Obat*</label>
                    <input type="text" class="form-control" id="obat" placeholder="pilih obat" readonly required data-bs-toggle="modal" data-bs-target="#pilihObatModal">
                
                    <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'number','name' => 'jml_obat','label' => 'Jumlah Obat','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'jml_obat','label' => 'Jumlah Obat','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                
                    <label for="harga" class="form-label">Harga*</label>
                    <input type="text" class="form-control" id="harga" name="harga" placeholder="Rp. 0" readonly required>
                
                    <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'keterangan','label' => 'Keterangan','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'keterangan','label' => 'Keterangan','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>

                    <button class="w-100 mt-2 btn btn-primary" type="button" onclick="TambahObat()">
                        <i class="fa fa-plus"></i> Tambah
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8 col-lg-8 col-sm-12 col-12">
        
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">
                        <i class="fa fa-pills"></i> Obat yang dikeluarkan
                    </h4>
                    <a href="<?php echo e(route('admin.rekam_medis.update-status').'?rekam_medis='.encryptStr($rekamMedis->id).'&status=selesai'); ?>" class="btn btn-success mb-3">
                        Selesaikan tanpa pemberian obat <i class="fa fa-check-circle fs-6"></i> 
                    </a>
                </div>

                <form action="<?php echo e(route('admin.obat.storeResep')); ?>" method="post">
                    <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <thead>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Jumlah</th>
                            <th>Harga</th>
                            <th>Total</th>
                            <th>Ket</th>
                            <th></th>
                        </thead>
    
                        <tbody id="tabel-obat">
                            
                        </tbody>
                        <tfoot>
                            <td colspan="2">
                                <strong>Total</strong>
                            </td>
                            <td id="total-harga" colspan="7">Rp. 0</td>
                        </tfoot>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
                    <div class="input-resep">
                        <?php echo csrf_field(); ?>
                        <input name="id_rekam_medis" type="hidden" value="<?php echo e(encryptStr($rekamMedis->id)); ?>">
                    </div>
                    <button class="btn btn-primary w-100" >Simpan dan selesaikan proses</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="pilihObatModal" tabindex="-1" aria-labelledby="pilihObatLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="pilihObatLabel">Pilih Obat</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <thead>
              <tr>
                <th></th>
                <th>Kode Obat</th>
                <th>Nama Obat</th>
                <th>Harga</th>
                <th>Satuan</th>
                <th>untuk BPJS</th>
                <th>Stok</th>
                
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <button data-bs-dismiss="modal" onclick="selectObat('<?php echo e(encryptStr($item->id)); ?>', '<?php echo e($item->kode); ?>', '<?php echo e($item->nama); ?>', '<?php echo e(formatRupiah($item->harga)); ?>')" class="btn btn-sm btn-primary">Pilih</button>
                        <td><?php echo e($item->kode); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e(formatRupiah($item->harga)); ?></td>
                        <td><?php echo e($item->satuan); ?></td>
                        <td><?php echo e($item->bpjs); ?></td>
                        <td><?php echo e($item->stok); ?></td>
                    </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
           <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    
     function selectObat(id, kode, nama, harga){
        $('#id_obat').val(id);
        $('#obat').val(nama);
        $('#harga').val(harga);
        $('#kode').val(kode);
     }
     
     function TambahObat(){
        let tabel = $('#tabel-obat');
        let input_resep = $('.input-resep');
        let id_obat = $('#id_obat').val();
        let kode = $('#kode').val();
        let nama = $('#obat').val();
        let harga = $('#harga').val();
        let jml_obat = $('#jml_obat').val();
        let keterangan = $('#keterangan').val();
        let total = jml_obat*parseRupiah(harga);

        let total_harga = $('#total-harga');

        
        if(!id_obat || !kode || !nama || !harga || !jml_obat){
            alert('Lengkapi data obat terlebih dahulu');
            console.log('id:' + id_obat, 'kode:' + kode, 'nama:' + nama, 'harga:' + harga, 'jumlah:' + jml_obat);
            return;
        }
        $('.dt-empty').html('');
        console.log(parseRupiah(total_harga.text()));
        total_harga.text(formatRupiah(parseRupiah(total_harga.text()) + total));

        tabel.prepend(`<tr>
            <td>${kode}</td>
            <td>${nama}</td>
            <td>${jml_obat}</td>
            <td>${formatRupiah(harga)}</td>
            <td class="total">${formatRupiah(total)}</td>
            <td>${keterangan}</td>
            <td>
                <button class="btn btn-danger" type="button" onclick="hapusRow(this)">
                <i class="fa fa-trash"></i>
                </button>
            </td>
        </tr>`);

        // input resep
        input_resep.append(`<input type="hidden" name="obat[]" value="${id_obat}">`);
        input_resep.append(`<input type="hidden" name="jml_obat[]" value="${jml_obat}">`);
        input_resep.append(`<input type="hidden" name="keterangan[]" value="${keterangan}">`);
        
     }
    </script>
    

    <script>
        function formatRupiah(angka, prefix = 'Rp. ') {
            const numberString = angka.toString().replace(/[^,\d]/g, '');
            const split = numberString.split(',');
            const sisa = split[0].length % 3;
            let rupiah = split[0].substr(0, sisa);
            const ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            // Tambahkan titik jika ribuan
            if (ribuan) {
                const separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;
            return prefix + rupiah;
        }

        function parseRupiah(rupiah) {
            return parseInt(rupiah.replace(/[^,\d]/g, ''), 10);
        }

        function hapusRow(button) {
            // Mendapatkan baris yang berisi tombol hapus
            const row = $(button).closest('tr');
            
            const harga = parseRupiah(row.find('.total').text());
            
            let total_harga = parseRupiah($('#total-harga').text());
            total_harga -= harga;
            
            $('#total-harga').text(formatRupiah(total_harga));

            row.remove();
        }

    </script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/obat/resep-create.blade.php ENDPATH**/ ?>