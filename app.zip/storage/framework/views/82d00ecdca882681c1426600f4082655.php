<?php $__env->startSection('content'); ?>
    <div class="mb-3">
        <a href="<?php echo e(route('admin.rekam_medis.create')); ?>" class="btn btn-primary"><i class="fa fa-plus-circle"></i> Rekam Medis Baru</a>
    </div>

    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Data Rekam Medis']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Data Rekam Medis']); ?>
        <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <thead>
                <th>No</th>
                <th>Tanggal</th>
                <th>Nama Pasien</th>
                <th>Poli/Dokter</th>
                <th>Ammanesia/Kesimpulan</th>
                <th>Cara Bayar</th>
                <th>Status</th>
                <th></th>
            </thead>

            <tbody>
                <?php $__currentLoopData = $rekamMedis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->created_at->format('d/m/Y H:i:s')); ?></td>
                        <td><?php echo e($item->pasien->user->name); ?></td>
                        <td>
                            <dl>
                                <dt>Poli</dt>
                                <dd><?php echo e($item->poli->name); ?></dd>
                                <dt>Dokter</dt>
                                <dd><?php echo e($item->dokter->user->name); ?></dd>
                            </dl>
                        </td>
                        <td>
                            <dl>
                                <dt>Ammanesia</dt>
                                <dd><?php echo e($item->ammanesia); ?></dd>
                                <dt>Kesimpulan</dt>
                                <dd><?php echo e($item->kesimpulan); ?></dd>
                            </dl>
                        </td>
                        <td>
                            <?php if($item->jenis_pembayaran == 'jaminan kesehatan'): ?>
                                <span class="badge bg-success"><?php echo e($item->jenis_pembayaran); ?></span>
                            <?php else: ?> 
                                <span class="badge bg-muted"><?php echo e($item->jenis_pembayaran); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($item->status == 'selesai'): ?>
                                <span class="badge bg-success"><?php echo e($item->status); ?></span>
                            <?php else: ?>
                                <span class="badge bg-warning"><?php echo e($item->status); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="row">
                                <div class="col-auto p-2">
                                    <a href="<?php echo e(route('admin.rekam_medis.detail', encryptStr($item->pasien->id))); ?>" class="btn btn-info">
                                        <i class="fas fa-user-md"></i>
                                    </a>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/rekam-medis/index.blade.php ENDPATH**/ ?>