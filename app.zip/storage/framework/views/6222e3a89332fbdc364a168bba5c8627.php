<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h3 class="card-title">Tambah Rekam Medis Baru</h3>
            <form action="<?php echo e(route('admin.rekam_medis.store')); ?>" method="post" class="form-group">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="pasien" id="id_pasien" required>
                
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="kandungan" class="form-label">Kandungan</label>
                        <select name="kandungan" id="kandungan" onclick="formKandungan()" class="form-select" required>
                            <option value="0">Tidak</option>
                            <option value="1">Ya</option>
                        </select>
                    </div>

                    <div class="col-md-6 col-lg-6 col-12">
                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e(date('Y-m-d')).'','type' => 'date','name' => 'tgl_pemeriksaan','label' => 'Tanggal Pemeriksaan','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(date('Y-m-d')).'','type' => 'date','name' => 'tgl_pemeriksaan','label' => 'Tanggal Pemeriksaan','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="pilih-pasien" class="form-label">Pilih Pasien</label>
                        <input type="text" id="pilih-pasien" name="nama_pasien" class="form-control" placeholder="Klik untuk memilih pasien" readonly data-bs-toggle="modal" data-bs-target="#modalPilihPasien">
                    </div>

                    <div class="col-md-6 col-lg-6 col-12 ">
                        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'jenis_pembayaran','label' => 'Jenis Pembayaran']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'jenis_pembayaran','label' => 'Jenis Pembayaran']); ?>
                            <option value="umum/mandiri">Umum/Mandiri</option>
                            <option value="jaminan kesehatan">Jaminan Kesehatan</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="form-kandungan" style="display: none">
                    <label for="username" class="form-label mt-2">Riwayat Persalinan yang Lalu</label>
                    <div class="input-group mb-3">
                        <span class="input-group-text">G</span>
                        <input type="text" class="form-control" name="g" placeholder="G" aria-label="G">
                        <span class="input-group-text">P</span>
                        <input type="text" class="form-control" name="p" placeholder="P" aria-label="P">
                        <span class="input-group-text">A</span>
                        <input type="text" class="form-control" name="a" placeholder="A" aria-label="A">
                    </div>
                </div>

                <label for="ammanesia" class="form-label">Ammanesia</label>
                <textarea name="ammanesia" id="ammanesia" cols="30" rows="4" class="form-control" required></textarea>

                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="riwayat_penyakit" class="form-label">Riwayat Penyakit</label>
                        <textarea name="riwayat_penyakit" id="riwayat_penyakit" cols="30" rows="4" class="form-control"></textarea>  
                    </div>

                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="riwayat_penyakit_keluarga" class="form-label">Riwayat Penyakit Keluarga</label>
                        <textarea name="riwayat_penyakit_keluarga" id="riwayat_penyakit_keluarga" cols="30" rows="4" class="form-control"></textarea>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'poli','label' => 'Poli Tujuan','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'poli','label' => 'Poli Tujuan','required' => true]); ?>
                            <?php $__currentLoopData = $poli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>    
                    </div>

                    <div class="col-md-6 col-lg-6 col-12">
                        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'dokter','label' => 'Dokter','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'dokter','label' => 'Dokter','required' => true]); ?>
                            <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                    </div>
                </div>

                <div class="mt-3">
                    <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i> Simpan</button> <button class="btn btn-danger" type="reset"><i class="fa fa-times"></i> Batal</button>
                </div>
            </form>
            
            <!-- Modal untuk memilih pasien -->
            <div class="modal fade" id="modalPilihPasien" tabindex="-1" aria-labelledby="modalPilihPasienLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="modalPilihPasienLabel">Pilih Pasien</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Pasien</th>
                                        <th>No. Rekam Medis</th>
                                        <th>Tanggal Lahir</th>
                                        <th>No Hp</th>
                                        <th>Cara Bayar</th>
                                        <th>No BPJS/KTP</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <button type="button" class="btn btn-primary pilih-pasien-btn" data-nama="<?php echo e($p->user->name); ?>" data-id="<?php echo e($p->id); ?>" data-bs-dismiss="modal">Pilih</button>
                                        </td>
                                        <td><?php echo e($p->user->name); ?></td>
                                        <td><?php echo e($p->no_rm); ?></td>
                                        <td><?php echo e($p->tanggal_lahir); ?></td>
                                        <td><?php echo e($p->no_hp); ?></td>
                                        <td><?php echo e($p->jenis_pembayaran); ?></td>
                                        <td><?php echo e($p->no_bpjs); ?></td>
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <script>
                document.querySelectorAll('.pilih-pasien-btn').forEach(function(button) {
                    button.addEventListener('click', function() {
                        const namaPasien = this.getAttribute('data-nama');
                        const idPasien = this.getAttribute('data-id');
            
                        // Set nilai input text dengan nama pasien yang dipilih
                        document.getElementById('pilih-pasien').value = namaPasien;
            
                        $('#id_pasien').val(idPasien);
                    });
                });

                function formKandungan(){
                    const kandungan = $('#kandungan').val();
                    console.log(kandungan)
                    if(kandungan == 0){
                        $('#form-kandungan').hide();
                    } else{
                        $('#form-kandungan').show();
                    }
                }
            </script>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/rekam-medis/create.blade.php ENDPATH**/ ?>