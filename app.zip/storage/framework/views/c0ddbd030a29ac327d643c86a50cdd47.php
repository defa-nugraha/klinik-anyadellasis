<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <h5 class="card-title fw-semibold mb-4">Sample Page</h5>
      <p class="mb-0">This is a sample page </p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/MY STARTUP/lame pedia/web/resources/views/admin/index.blade.php ENDPATH**/ ?>