<?php $__env->startSection('content'); ?>
<div class="card shadow-lg">
    <div class="card-body">
        <form action="<?php echo e(route('admin.produk.prepaid')); ?>" method="get" class="form-group">
            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'category','label' => 'Kategori']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'category','label' => 'Kategori']); ?>
                <option value="all" selected>Semua Kategori</option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(encryptStr($c->id)); ?>" <?php echo e(($category_id != 'all') ? (decryptStr($category_id) == decryptStr(encryptStr($c->id))) ? 'selected' : '' : ''); ?>>
                        <a href=""><?php echo e($c->name); ?></a>
                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
            <button class="btn btn-primary mt-2" type="submit">
               <i class="ti ti-search"></i> Cari
            </button>
        </form>
    </div>
</div>

<div class="card shadow-lg">
    <div class="card-body">
      <h5 class="card-title fw-semibold mb-4">Data Produk Prepaid</h5>
      <a href="<?php echo e(route('admin.produk.update_produk.prepaid')); ?>" class="btn btn-primary">
        Update Produk
      </a>

      <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <thead>
            <th>No</th>
            <th>Kode</th>
            <th>Kategori/Produk</th>
            <th>Harga</th>
            <th>Keuntungan</th>
        </thead>

        <tbody>
           
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $hargaJual = hitungHargaJual($p->price);   
                ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($p->buyer_sku_code); ?></td>
                    <td>
                        <span><?php echo e($p->brand->name); ?> 
                            <span class="text-warning">
                                [<?php echo e($p->category->name); ?>]
                            </span>    
                        </span> <br>
                        <span class="text-info"><?php echo e($p->product_name); ?></span>
                        <br>
                        <span class="<?php echo e(($p->seller_product_status) ? 'text-success' : 'text-danger'); ?>">
                            <?php echo e(($p->seller_product_status) ? '[Tersedia]' : '[Tidak Tersedia]'); ?>

                        </span>
                    </td>
                    <td>
                        <ul>
                            <li>Harga asli <?php echo e(formatRupiah($p->price)); ?></li>
                            <li>Harga jual <?php echo e(formatRupiah($hargaJual)); ?></li>
                        </ul>
                    </td>
                    <td><?php echo e(formatRupiah(hitungKeuntungan($hargaJual, $p->price))); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
       <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/MY STARTUP/lame pedia/web/resources/views/admin/produk/index.blade.php ENDPATH**/ ?>