<link rel="stylesheet" href="https://cdn.ckeditor.com/ckeditor5/43.0.0/ckeditor5.css">
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title">Detail Pasien</h4>
                    <span class="text-muted">RM# <?php echo e($pasien->no_rm); ?></span>
                </div>
                <hr>
                
                <!-- Responsive Grid -->
                <div class="row">
                    <!-- Detail Pasien -->
                    <div class="col-md-4">
                        <h5><i class="fas fa-user"></i> Detail Pasien</h5>
                        <dl>
                            <dt><i class="fas fa-user"></i> Nama</dt>
                            <dd><?php echo e($pasien->user->name); ?>, <?php echo e($pasien->gender); ?> (<?php echo e($pasien->status_menikah); ?>)</dd>
                            <dt><i class="fas fa-calendar-alt"></i> Tempat, Tanggal Lahir</dt>
                            <dd><?php echo e($pasien->tempat_lahir); ?>, <?php echo e($pasien->tanggal_lahir); ?></dd>
                            <dt><i class="fas fa-briefcase"></i> Pekerjaan, Pendidikan</dt>
                            <dd><?php echo e($pasien->pekerjaan); ?>, <?php echo e($pasien->pendidikan); ?></dd>
                            <dt><i class="fas fa-map-marker-alt"></i> Alamat</dt>
                            <dd><?php echo e($pasien->alamat); ?></dd>
                        </dl>
                    </div>
                    
                    <!-- Info Pasien -->
                    <div class="col-md-4">
                        <h5><i class="fas fa-info-circle"></i> Info Pasien</h5>
                        <dl>
                            <dt><i class="fas fa-phone-alt"></i> No HP</dt>
                            <dd><?php echo e($pasien->no_hp); ?></dd>
                            <dt><i class="fas fa-id-card"></i> No BPJS/KTP</dt>
                            <dd><?php echo e($pasien->no_bpjs); ?></dd>
                            <dt><i class="fas fa-credit-card"></i> Pembayaran</dt>
                            <dd><?php echo e($pasien->jenis_pembayaran); ?></dd>
                            <dt><i class="fas fa-exclamation-triangle"></i> Alergi</dt>
                            <dd><?php echo e($pasien->alergi); ?></dd>
                        </dl>
                    </div>

                    <!-- Detail Suami/Istri (Jika Menikah) -->
                    <?php if($pasien->status_menikah == 'menikah'): ?>
                        <div class="col-md-4">
                            <h5><i class="fas fa-heart"></i> Detail <?php echo e($pasien->gender == 'laki-laki' ? 'Istri' : 'Suami'); ?></h5>
                            <dl>
                                <dt><i class="fas fa-user"></i> Nama</dt>
                                <dd><?php echo e($suamiIstri->nama); ?></dd>
                                <dt><i class="fas fa-phone-alt"></i> No HP</dt>
                                <dd><?php echo e($suamiIstri->no_hp); ?></dd>
                                <dt><i class="fas fa-id-card"></i> No BPJS/KTP</dt>
                                <dd><?php echo e($suamiIstri->no_bpjs); ?></dd>
                                <dt><i class="fas fa-calendar-alt"></i> Tempat, Tanggal Lahir</dt>
                                <dd><?php echo e($suamiIstri->tempat_lahir); ?>, <?php echo e($suamiIstri->tanggal_lahir); ?></dd>
                                <dt><i class="fas fa-briefcase"></i> Pekerjaan, Pendidikan</dt>
                                <dd><?php echo e($suamiIstri->pekerjaan); ?>, <?php echo e($suamiIstri->pendidikan); ?></dd>
                            </dl>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

    
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <h4 class="card-title">Rekam Medis Pasien</h4>
                <?php if($statusRekamMedis): ?>
                    <?php if($statusRekamMedis->status == 'antrian'): ?>
                        <a href="<?php echo e(route('admin.rekam_medis.update-status').'?rekam_medis='.encryptStr($statusRekamMedis->id).'&status=pemeriksaan'); ?>" class="btn btn-primary">Lanjutkan ke dokter <i class="fas fa-chevron-right"></i></a>
                    <?php elseif($statusRekamMedis->status == 'pemeriksaan'): ?>
                        <a href="<?php echo e(route('admin.rekam_medis.update-status').'?rekam_medis='.encryptStr($statusRekamMedis->id).'&status=di apotek'); ?>" class="btn btn-primary">Selesaikan pemeriksaan & perawatan <i class="fas fa-chevron-right"></i></a>
                    <?php elseif($statusRekamMedis->status == 'di apotek'): ?>
                        <a href="<?php echo e(route('admin.rekam_medis.update-status').'?rekam_medis='.encryptStr($statusRekamMedis->id).'&status=selesai'); ?>" class="btn btn-primary">Selesaikan rekam medis ini <i class="fas fa-chevron-right"></i></a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <thead>
                    <th>No</th>
                    <th>Tanggal Periksa</th>
                    <?php if($pasien->status_menikah == 'menikah'): ?>
                        <th>Riwayat Persalinan</th>
                    <?php endif; ?>
                    <th style="min-width: 170px">Ammanesia (S)</th>
                    <th style="min-width: 170px">Pemeriksaan (O)</th>
                    <th style="min-width: 170px">Diagnosa (A)</th>
                    <th style="min-width: 170px">Tindakan (P)</th>
                    <th></th>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $rekamMedis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->created_at->format('d/m/Y H:i:s')); ?></td>
                            <?php if($pasien->status_menikah == 'menikah'): ?>
                            
                                <td>
                                    <?php if($item->id_rm_kandungan): ?>
                                    G: <?php echo e($item->riwayat_persalinan->g); ?>

                                    P: <?php echo e($item->riwayat_persalinan->p); ?>

                                    A: <?php echo e($item->riwayat_persalinan->a); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                            <td><?php echo e($item->ammanesia); ?></td>
                            <td>
                                <?php if($item->id_pemeriksaan): ?>
                                <dl>
                                    <dt>Pemeriksaan</dt>
                                    <dd><?php echo $item->pemeriksaan->deskripsi; ?></dd>
                                    <dt>File Pemeriksaan</dt>
                                    <dd>
                                        <?php if($item->pemeriksaan->file_pemeriksaan): ?>
                                            <a href="<?php echo e(asset('file/pemeriksaan/'.$item->pemeriksaan->file_pemeriksaan)); ?>" target="_blank">Lihat</a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                        
                                    </dd>
                                </dl>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->id_diagnosa): ?>
                                <dl>
                                    <dt>Diagnosa</dt>
                                    <dd><?php echo $item->diagnosa->deskripsi; ?></dd>
                                    <dt>File Diagnosa</dt>
                                    <dd>
                                        <?php if($item->diagnosa->file_diagnosa): ?>
                                            <a href="<?php echo e(asset('file/diagnosa/'.$item->diagnosa->file_diagnosa)); ?>" target="_blank">Lihat</a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                        
                                    </dd>
                                </dl>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->id_tindakan): ?>
                                <dl>
                                    <dt>Tindakan</dt>
                                    <dd><?php echo $item->tindakan->deskripsi; ?></dd>
                                    <dt>File Tindakan</dt>
                                    <dd>
                                        <?php if($item->tindakan->file_tindakan): ?>
                                            <a href="<?php echo e(asset('file/tindakan/'.$item->tindakan->file_tindakan)); ?>" target="_blank">Lihat</a>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                        
                                    </dd>
                                </dl>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->status != 'selesai'): ?>
                                    <div class="row">
                                        <div class="col-auto p-2">
                                            <button class="btn btn-primary btn-sm"  data-bs-toggle="modal" data-bs-target="#modalPemeriksaan<?php echo e($item->id); ?>">
                                                <i class="fa fa-pencil"></i> Objeck
                                            </button>
                                            <!-- Modal untuk isi pemeriksaan -->
                                            <div class="modal fade" id="modalPemeriksaan<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="modalPemeriksaan<?php echo e($item->id); ?>Label" aria-hidden="true">
                                                <div class="modal-dialog modal-xl">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="modalPemeriksaan<?php echo e($item->id); ?>Label">Pemeriksaan</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('admin.pemeriksaan.createOrUpdate')); ?>" method="post" enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="rekam_medis" value="<?php echo e(encryptStr($item->id)); ?>">
                                                                <label for="pemeriksaan" class="form-label">Pemeriksaan*</label>
                                                                <textarea id="editor" name="pemeriksaan" class="form-control mb-3"><?php echo e(($item->pemeriksaan) ? $item->pemeriksaan->deskripsi : ''); ?></textarea>
                                                                <div class="mt-3">
                                                                    <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'file','name' => 'file_pemeriksaan','label' => 'File (optional)','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'file','name' => 'file_pemeriksaan','label' => 'File (optional)','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                                                                </div>

                                                                <button class="btn btn-primary mt-3">SIMPAN</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto p-2">
                                            <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalDiagnosa<?php echo e($item->id); ?>">
                                                <i class="fa fa-pencil"></i> Assessment
                                            </button>

                                            <!-- Modal untuk isi diagnosa -->
                                            <div class="modal fade" id="modalDiagnosa<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="modalDiagnosa<?php echo e($item->id); ?>Label" aria-hidden="true">
                                                <div class="modal-dialog modal-xl">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="modalDiagnosa<?php echo e($item->id); ?>Label">Diagnosa</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('admin.diagnosa.createOrUpdate')); ?>" method="post" enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="rekam_medis" value="<?php echo e(encryptStr($item->id)); ?>">
                                                                <label for="diagnosa" class="form-label">Diagnosa*</label>
                                                                <textarea id="diagnosa-editor" name="diagnosa" class="form-control mb-3"><?php echo e(($item->diagnosa) ? $item->diagnosa->deskripsi : ''); ?></textarea>
                                                                <div class="mt-3">
                                                                    <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'file','name' => 'file_diagnosa','label' => 'File (optional)','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'file','name' => 'file_diagnosa','label' => 'File (optional)','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                                                                </div>

                                                                <button class="btn btn-primary mt-3">SIMPAN</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto p-2">
                                            <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#modalTindakan<?php echo e($item->id); ?>">
                                                <i class="fa fa-pencil"></i> Plan
                                            </button>

                                            <!-- Modal untuk isi tindakan -->
                                            <div class="modal fade" id="modalTindakan<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="modalTindakan<?php echo e($item->id); ?>Label" aria-hidden="true">
                                                <div class="modal-dialog modal-xl">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="modalTindakan<?php echo e($item->id); ?>Label">Tindakan</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('admin.tindakan.createOrUpdate')); ?>" method="post" enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <input type="hidden" name="rekam_medis" value="<?php echo e(encryptStr($item->id)); ?>">
                                                                <label for="tindakan" class="form-label">Tindakan*</label>
                                                                <textarea id="tindakan-editor" name="tindakan" class="form-control mb-3"><?php echo e(($item->tindakan) ? $item->tindakan->deskripsi : ''); ?></textarea>
                                                                <div class="mt-3">
                                                                    <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'file','name' => 'file_tindakan','label' => 'File (optional)','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'file','name' => 'file_tindakan','label' => 'File (optional)','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                                                                </div>

                                                                <button class="btn btn-primary mt-3">SIMPAN</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>  
                                    <a href="<?php echo e(route('admin.obat-keluar.detail', encryptStr($item->id))); ?>" class="btn btn-sm btn-success">
                                        <i class="fa fa-eye"></i> Obat
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>



<!-- Page Specific JS File -->
<script type="importmap">
    {
        "imports": {
            "ckeditor5": "https://cdn.ckeditor.com/ckeditor5/43.0.0/ckeditor5.js",
            "ckeditor5/": "https://cdn.ckeditor.com/ckeditor5/43.0.0/"
        }
    }
</script>
<script type="module">
    import {
        ClassicEditor,
        Essentials,
        Paragraph,
        Bold,
        Italic,
        Font
    } from 'ckeditor5';
    ClassicEditor
        .create( document.querySelector( '#editor' ), {
            plugins: [ Essentials, Paragraph, Bold, Italic, Font, Image ],
            toolbar: [
                'undo', 'redo', '|', 'bold', 'italic', '|',
                'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor'
            ]
        } )
        .then( editor => {
            window.editor = editor;
        } )
        .catch( error => {
            console.error( error );
    } );
</script>

<script type="module">
    import {
        ClassicEditor,
        Essentials,
        Paragraph,
        Bold,
        Italic,
        Font
    } from 'ckeditor5';
    ClassicEditor
        .create( document.querySelector( '#diagnosa-editor' ), {
            plugins: [ Essentials, Paragraph, Bold, Italic, Font, Image ],
            toolbar: [
                'undo', 'redo', '|', 'bold', 'italic', '|',
                'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor'
            ]
        } )
        .then( editor => {
            window.editor = editor;
        } )
        .catch( error => {
            console.error( error );
    } );
</script>

<script type="module">
    import {
        ClassicEditor,
        Essentials,
        Paragraph,
        Bold,
        Italic,
        Font
    } from 'ckeditor5';
    ClassicEditor
        .create( document.querySelector( '#tindakan-editor' ), {
            plugins: [ Essentials, Paragraph, Bold, Italic, Font, Image ],
            toolbar: [
                'undo', 'redo', '|', 'bold', 'italic', '|',
                'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor'
            ]
        } )
        .then( editor => {
            window.editor = editor;
        } )
        .catch( error => {
            console.error( error );
    } );
</script>

<!-- A friendly reminder to run on a server, remove this during the integration. -->
<script>
    window.onload = function() {
        if ( window.location.protocol === 'file:' ) {
            alert( 'This sample requires an HTTP server. Please serve this file with a web server.' );
        }
    };
</script>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/rekam-medis/detail.blade.php ENDPATH**/ ?>