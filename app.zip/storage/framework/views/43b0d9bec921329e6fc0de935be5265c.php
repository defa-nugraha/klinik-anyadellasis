<?php $__env->startSection('dashboard-content'); ?>
<?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <thead>
        <th>No</th>
        <th>Tanggal Periksa</th>
        <?php if($profil->status_menikah == 'menikah'): ?>
            <th>Riwayat Persalinan</th>
        <?php endif; ?>
        <th style="min-width: 170px">Ammanesia (S)</th>
        <th style="min-width: 170px">Pemeriksaan (O)</th>
        <th style="min-width: 170px">Diagnosa (A)</th>
        <th style="min-width: 170px">Tindakan (P)</th>
    </thead>

    <tbody>
        <?php $__currentLoopData = $rekamMedis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($item->created_at->format('d/m/Y H:i:s')); ?></td>
                <?php if($profil->status_menikah == 'menikah'): ?>
                
                    <td>
                        <?php if($item->id_rm_kandungan): ?>
                        G: <?php echo e($item->riwayat_persalinan->g); ?>

                        P: <?php echo e($item->riwayat_persalinan->p); ?>

                        A: <?php echo e($item->riwayat_persalinan->a); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                <?php endif; ?>
                <td><?php echo e($item->ammanesia); ?></td>
                <td>
                    <?php if($item->id_pemeriksaan): ?>
                    <dl>
                        <dt>Pemeriksaan</dt>
                        <dd><?php echo $item->pemeriksaan->deskripsi; ?></dd>
                        <dt>File Pemeriksaan</dt>
                        <dd>
                            <?php if($item->pemeriksaan->file_pemeriksaan): ?>
                                <a href="<?php echo e(asset('file/pemeriksaan/'.$item->pemeriksaan->file_pemeriksaan)); ?>" target="_blank">Lihat</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                            
                        </dd>
                    </dl>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($item->id_diagnosa): ?>
                    <dl>
                        <dt>Diagnosa</dt>
                        <dd><?php echo $item->diagnosa->deskripsi; ?></dd>
                        <dt>File Diagnosa</dt>
                        <dd>
                            <?php if($item->diagnosa->file_diagnosa): ?>
                                <a href="<?php echo e(asset('file/diagnosa/'.$item->diagnosa->file_diagnosa)); ?>" target="_blank">Lihat</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                            
                        </dd>
                    </dl>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td>
                    <?php if($item->id_tindakan): ?>
                    <dl>
                        <dt>Tindakan</dt>
                        <dd><?php echo $item->tindakan->deskripsi; ?></dd>
                        <dt>File Tindakan</dt>
                        <dd>
                            <?php if($item->tindakan->file_tindakan): ?>
                                <a href="<?php echo e(asset('file/tindakan/'.$item->tindakan->file_tindakan)); ?>" target="_blank">Lihat</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                            
                        </dd>
                    </dl>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-pasien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/pasien/rekam-medis/index.blade.php ENDPATH**/ ?>