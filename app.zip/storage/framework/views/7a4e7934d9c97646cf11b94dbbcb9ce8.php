<label for="<?php echo e($name); ?>" class="form-label"><?php echo e($label); ?></label>
<input onKeyup="format(this)" type="<?php echo e($type); ?>" value="<?php echo e($value); ?>" class="form-control" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" value="<?php echo e(old($name)); ?>" placeholder="<?php echo e($label); ?>">

<?php if (isset($component)) { $__componentOriginal73fe2d403c586f5e77c51edaa9deccda = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73fe2d403c586f5e77c51edaa9deccda = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components._formatRupiah','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('_formatRupiah'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73fe2d403c586f5e77c51edaa9deccda)): ?>
<?php $attributes = $__attributesOriginal73fe2d403c586f5e77c51edaa9deccda; ?>
<?php unset($__attributesOriginal73fe2d403c586f5e77c51edaa9deccda); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73fe2d403c586f5e77c51edaa9deccda)): ?>
<?php $component = $__componentOriginal73fe2d403c586f5e77c51edaa9deccda; ?>
<?php unset($__componentOriginal73fe2d403c586f5e77c51edaa9deccda); ?>
<?php endif; ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/components/input-rupiah.blade.php ENDPATH**/ ?>