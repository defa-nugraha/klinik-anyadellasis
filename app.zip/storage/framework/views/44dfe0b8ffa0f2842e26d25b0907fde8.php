<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h4 class="card-title"><i class="fa fa-user-injured"></i> Tambah Pasien Baru</h4>
        
            <form action="<?php echo e(route('admin.pasien.update')); ?>" method="post" class="form-group">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="user" value="<?php echo e(encryptStr($pasien->user->id)); ?>">
                <input type="hidden" name="id" value="<?php echo e(encryptStr($pasien->id)); ?>">
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->user->name).'','type' => 'text','name' => 'name','label' => 'Nama Pasien','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->user->name).'','type' => 'text','name' => 'name','label' => 'Nama Pasien','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->no_rm).'','type' => 'text','name' => 'no_rm','label' => 'Nomor RM','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->no_rm).'','type' => 'text','name' => 'no_rm','label' => 'Nomor RM','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->tempat_lahir).'','type' => 'text','name' => 'tempat_lahir','label' => 'Tempat Lahir','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->tempat_lahir).'','type' => 'text','name' => 'tempat_lahir','label' => 'Tempat Lahir','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                        
                        <label for="gender">Jenis Kelamin*</label>
                        <select name="gender" id="gender" class="form-select" required onchange="formSuamiIstri()">
                            <option value="laki-laki" <?php echo e($pasien->gender == 'laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                            <option value="perempuan" <?php echo e($pasien->gender == 'perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                        </select>

                        <label for="agama">Agama*</label>
                        <select name="agama" id="agama" class="form-select" required>
                            <option value="" selected disabled>--Pilih--</option>
                            <option value="islam" <?php echo e($pasien->agama == 'islam' ? 'selected' : ''); ?>>Islam</option>
                            <option value="kristen" <?php echo e($pasien->agama == 'kristen' ? 'selected' : ''); ?>>Kristen</option>
                            <option value="khatolik" <?php echo e($pasien->agama == 'khatolik' ? 'selected' : ''); ?>>Khatolik</option>
                            <option value="hindu" <?php echo e($pasien->agama == 'hindu' ? 'selected' : ''); ?>>Hindu</option>
                            <option value="budha" <?php echo e($pasien->agama == 'budha' ? 'selected' : ''); ?>>Budha</option>
                            <option value="konghucu" <?php echo e($pasien->agama == 'konghucu' ? 'selected' : ''); ?>>Konghucu</option>
                        </select>

                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->no_hp).'','type' => 'text','name' => 'no_hp','label' => 'No HP','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->no_hp).'','type' => 'text','name' => 'no_hp','label' => 'No HP','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>

                        <label for="jenis_pembayaran">Cara Bayar*</label>
                        <select name="jenis_pembayaran" id="jenis_pembayaran" class="form-select" required>
                            <option value="" selected disabled>--Pilih--</option>
                            <option value="umum/mandiri" <?php echo e($pasien->jenis_pembayaran == 'umum/mandiri' ? 'selected' : ''); ?>>Umum/Mandiri</option>
                            <option value="jaminan kesehatan" <?php echo e($pasien->jenis_pembayaran == 'jaminan kesehatan' ? 'selected' : ''); ?>>Jaminan Kesehatan</option>
                        </select>

                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->pekerjaan).'','type' => 'text','name' => 'pekerjaan','label' => 'Pekerjaan','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->pekerjaan).'','type' => 'text','name' => 'pekerjaan','label' => 'Pekerjaan','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                    </div>

                    <div class="col-md-6 col-lg-6 col-12">
                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->no_bpjs).'','type' => 'text','name' => 'no_bpjs','label' => 'No. BPJS/KTP','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->no_bpjs).'','type' => 'text','name' => 'no_bpjs','label' => 'No. BPJS/KTP','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->tanggal_lahir).'','type' => 'date','name' => 'tanggal_lahir','label' => 'Tanggal Lahir','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->tanggal_lahir).'','type' => 'date','name' => 'tanggal_lahir','label' => 'Tanggal Lahir','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                        
                        <label for="status_menikah">Status Menikah*</label>
                        <select name="status_menikah" id="status_menikah" class="form-select" required  onchange="formSuamiIstri()">
                            <option value="" selected disabled>--Pilih--</option>
                            <option value="belum menikah" <?php echo e($pasien->status_menikah == 'belum menikah' ? 'selected' : ''); ?>>Belum Menikah</option>
                            <option value="menikah" <?php echo e($pasien->status_menikah == 'menikah' ? 'selected' : ''); ?>>Menikah</option>
                            <option value="duda" <?php echo e($pasien->status_menikah == 'duda' ? 'selected' : ''); ?>>Duda</option>
                            <option value="janda" <?php echo e($pasien->status_menikah == 'janda' ? 'selected' : ''); ?>>Janda</option>
                        </select>

                        <label for="pendidikan">Pendidikan*</label>
                        <select name="pendidikan" id="pendidikan" class="form-select" required>
                            <option value="" selected disabled>--Pilih--</option>
                            <option value="SD" <?php echo e($pasien->pendidikan == 'SD' ? 'selected' : ''); ?>>SD</option>
                            <option value="SMP/Sederajat" <?php echo e($pasien->pendidikan == 'SMP/Sederajat' ? 'selected' : ''); ?>>SMP/Sederajat</option>
                            <option value="SMA/Sederajat" <?php echo e($pasien->pendidikan == 'SMA/Sederajat' ? 'selected' : ''); ?>>SMA/Sederajat</option>
                            <option value="Diploma" <?php echo e($pasien->pendidikan == 'Diploma' ? 'selected' : ''); ?>>Diploma</option>
                            <option value="S1/Sederajat" <?php echo e($pasien->pendidikan == 'S1/Sederajat' ? 'selected' : ''); ?>>S1/Sederajat</option>
                            <option value="S2/Sederajat" <?php echo e($pasien->pendidikan == 'S2/Sederajat' ? 'selected' : ''); ?>>S2/Sederajat</option>
                            <option value="S3/Sederajat" <?php echo e($pasien->pendidikan == 'S3/Sederajat' ? 'selected' : ''); ?>>S3/Sederajat</option>
                            <option value="Tidak Sekolah" <?php echo e($pasien->pendidikan == 'Tidak Sekolah' ? 'selected' : ''); ?>>Tidak Sekolah</option>
                        </select>

                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->user->email).'','type' => 'email','name' => 'email','label' => 'Email (digunakan username dan password)','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->user->email).'','type' => 'email','name' => 'email','label' => 'Email (digunakan username dan password)','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                        
                        <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($pasien->alergi).'','type' => 'text','name' => 'alergi','label' => 'Alergi','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($pasien->alergi).'','type' => 'text','name' => 'alergi','label' => 'Alergi','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>

                        <label for="alamat">Alamat Lengkap</label>
                        <textarea name="alamat" id="alamat" class="form-control" cols="30" rows="5"><?php echo e($pasien->alamat); ?></textarea>                        
                    </div>
                </div>
                <hr>
                <div class="suami-istri" style="display: <?php echo e((!$suamiIstri) ? 'none' : ''); ?>">
                    <input type="hidden" name="suami_istri" value="<?php echo e(($suamiIstri) ? encryptStr($suamiIstri->id) : ''); ?>">
                    <h3 id="title">Data <?php echo e($pasien->gender == 'laki-laki' ? 'Istri' : 'Suami'); ?></h3>
                    <div class="row">
                        <div class="col-md-6 col-lg-6 col-12">
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e(($suamiIstri) ? $suamiIstri->nama : '').'','type' => 'text','name' => 'nama_ss','label' => 'Nama','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e(($suamiIstri) ? $suamiIstri->nama : '').'','type' => 'text','name' => 'nama_ss','label' => 'Nama','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($suamiIstri ? $suamiIstri->tempat_lahir : '').'','type' => 'text','name' => 'tempat_lahir_ss','label' => 'Tempat Lahir','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($suamiIstri ? $suamiIstri->tempat_lahir : '').'','type' => 'text','name' => 'tempat_lahir_ss','label' => 'Tempat Lahir','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($suamiIstri ? $suamiIstri->tanggal_lahir: '').'','type' => 'date','name' => 'tanggal_lahir_ss','label' => 'Tanggal Lahir','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($suamiIstri ? $suamiIstri->tanggal_lahir: '').'','type' => 'date','name' => 'tanggal_lahir_ss','label' => 'Tanggal Lahir','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($suamiIstri ? $suamiIstri->pekerjaan : '').'','type' => 'text','name' => 'pekerjaan_ss','label' => 'Pekerjaan','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($suamiIstri ? $suamiIstri->pekerjaan : '').'','type' => 'text','name' => 'pekerjaan_ss','label' => 'Pekerjaan','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            
                        </div>
                        
                        <div class="col-md-6 col-lg-6 col-12">
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($suamiIstri ? $suamiIstri->no_bpjs : '').'','type' => 'text','name' => 'no_bpjs_ss','label' => 'No. BPJS/KTP','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($suamiIstri ? $suamiIstri->no_bpjs : '').'','type' => 'text','name' => 'no_bpjs_ss','label' => 'No. BPJS/KTP','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($suamiIstri ? $suamiIstri->no_hp : '').'','type' => 'text','name' => 'no_hp_ss','label' => 'No. HP','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($suamiIstri ? $suamiIstri->no_hp : '').'','type' => 'text','name' => 'no_hp_ss','label' => 'No. HP','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            
                            <label for="pendidikan">Pendidikan*</label>
                            <select name="pendidikan_ss" id="pendidikan" class="form-select">
                                <option value="" selected disabled>--Pilih--</option>
                                <option value="SD" <?php echo e(($suamiIstri) && $suamiIstri->pendidikan == 'SD' ? 'selected' : ''); ?>>SD</option>
                                <option value="SMP/Sederajat" <?php echo e(($suamiIstri) && $suamiIstri->pendidikan == 'SMP/Sederajat' ? 'selected' : ''); ?>>SMP/Sederajat</option>
                                <option value="SMA/Sederajat" <?php echo e(($suamiIstri) && $suamiIstri->pendidikan == 'SMA/Sederajat' ? 'selected' : ''); ?>>SMA/Sederajat</option>
                                <option value="Diploma" <?php echo e(($suamiIstri) && $suamiIstri->pendidikan == 'Diploma' ? 'selected' : ''); ?>>Diploma</option>
                                <option value="S1/Sederajat" <?php echo e(($suamiIstri) && $suamiIstri->pendidikan == 'S1/Sederajat' ? 'selected' : ''); ?>>S1/Sederajat</option>
                                <option value="S2/Sederajat" <?php echo e(($suamiIstri) && $suamiIstri->pendidikan == 'S2/Sederajat' ? 'selected' : ''); ?>>S2/Sederajat</option>
                                <option value="S3/Sederajat" <?php echo e(($suamiIstri) && $suamiIstri->pendidikan == 'S3/Sederajat' ? 'selected' : ''); ?>>S3/Sederajat</option>
                                <option value="Tidak Sekolah" <?php echo e(($suamiIstri) && $suamiIstri->pendidikan == 'Tidak Sekolah' ? 'selected' : ''); ?>>Tidak Sekolah</option>
                            </select>
                                
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary mt-3">SIMPAN</button>
            </form>
        </div>
    </div>

    <script>
        function formSuamiIstri(){
            const gender = $('#gender').val();
            const status_menikah = $('#status_menikah').val();

            let title = '';
            if(gender == 'laki-laki' && status_menikah == 'menikah'){
                title = 'Data Istri';
            } else if(gender == 'perempuan' && status_menikah == 'menikah'){
                title = 'Data Suami';
            }

            if(title){
                $('.suami-istri').show();
            } else{
                $('.suami-istri').hide();
            }
            // update text title
            $('#title').text(title)

        }
        formSuamiIstri()
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/pasien/edit.blade.php ENDPATH**/ ?>