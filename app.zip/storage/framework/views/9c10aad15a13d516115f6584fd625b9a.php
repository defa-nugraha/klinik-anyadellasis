<?php if(session('failed')): ?>
<div class="alert alert-danger" role="alert">
    <h4 class="alert-heading">GAGAL</h4>
    <div class="alert-body">
        <?php echo e(session('failed')); ?>

    </div>
</div>
<?php endif; ?>
<?php if(session('success')): ?>
<div class="alert alert-success" role="alert">
    <h4 class="alert-heading">SUKSES</h4>
    <div class="alert-body">
        <?php echo e(session('success')); ?>

    </div>
</div>
<?php endif; ?>
<?php if(session('info')): ?>
<div class="alert alert-info" role="alert">
    <h4 class="alert-heading">INFO</h4>
    <div class="alert-body">
        <?php echo e(session('info')); ?>

    </div>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <h4 class="alert-heading">ERROR</h4>
    <div class="alert-body">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php endif; ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/components/alert.blade.php ENDPATH**/ ?>