<div class="card shadow-lg">
    <div class="card-body">
        <h5 class="card-title fw-semibold mb-4">
            <i class="ti ti-package"></i>
            <?php echo e($title); ?></h5>
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/components/card.blade.php ENDPATH**/ ?>