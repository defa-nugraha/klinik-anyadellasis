<div class="table-responsive">
    <table class="table table-striped" id="table">
        <?php echo e($slot); ?>

    </table>
  </div><?php /**PATH /home/stardust/Documents/MY STARTUP/lame pedia/web/resources/views/components/table.blade.php ENDPATH**/ ?>