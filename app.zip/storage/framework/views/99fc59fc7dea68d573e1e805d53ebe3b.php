<div class="d-none d-md-block">
    <ul class="nav nav-tabs mt-4 flex-column flex-md-row">
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('pasien.dashboard')); ?>">Informasi Pasien</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('riwayat/pendaftaran*') ? 'active' : ''); ?>" href="<?php echo e(route('pasien.pendaftaran')); ?>">Riwayat Pendaftaran</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e(Request::is('riwayat/rekam-medis*') ? 'active' : ''); ?>" href="<?php echo e(route('pasien.rekam-medis')); ?>">Riwayat Rekam Medis</a>
        </li>
    </ul>
</div>

<div class="d-md-none">
    <h3>Informasi Pasien</h3>
</div><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/components/tab.blade.php ENDPATH**/ ?>