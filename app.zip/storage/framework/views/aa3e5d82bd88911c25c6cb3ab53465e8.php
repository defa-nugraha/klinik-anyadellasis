<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h3 class="card-title">Tambah Rekam Medis Baru</h3>
            <form action="<?php echo e(route('admin.rekam_medis.store')); ?>" method="post" class="form-group">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="pasien" id="id_pasien" required>
                
                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="kandungan" class="form-label">Kandungan</label>
                        <select name="kandungan" id="kandungan" onclick="formKandungan()" class="form-select" required>
                            <option value="0">Tidak</option>
                            <option value="1">Ya</option>
                        </select>
                    </div>

                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="">Tanggal Pemeriksaan</label>
                        <input value="<?php echo e($antrian->tanggal_periksa); ?>" type="date" name="tgl_pemeriksaan" class="form-control" readonly required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <input type="hidden" name="pasien" value="<?php echo e($pasien->id); ?>">
                        <label for="pilih-pasien" class="form-label">Nama Pasien</label>
                        <input type="text" id="pilih-pasien" value="<?php echo e($pasien->user->name); ?>" name="nama_pasien" class="form-control" readonly>
                    </div>

                    <div class="col-md-6 col-lg-6 col-12 ">
                        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'jenis_pembayaran','label' => 'Jenis Pembayaran']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'jenis_pembayaran','label' => 'Jenis Pembayaran']); ?>
                            <option value="umum/mandiri">Umum/Mandiri</option>
                            <option value="jaminan kesehatan">Jaminan Kesehatan</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                    </div>
                </div>

                <div id="form-kandungan" style="display: none">
                    <label for="username" class="form-label mt-2">Riwayat Persalinan yang Lalu</label>
                    <div class="input-group mb-3">
                        <span class="input-group-text">G</span>
                        <input type="text" class="form-control" name="g" placeholder="G" aria-label="G">
                        <span class="input-group-text">P</span>
                        <input type="text" class="form-control" name="p" placeholder="P" aria-label="P">
                        <span class="input-group-text">A</span>
                        <input type="text" class="form-control" name="a" placeholder="A" aria-label="A">
                    </div>
                </div>

                <label for="ammanesia" class="form-label">Ammanesia</label>
                <textarea name="ammanesia" id="ammanesia" cols="30" rows="4" class="form-control" required></textarea>

                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="riwayat_penyakit" class="form-label">Riwayat Penyakit</label>
                        <textarea name="riwayat_penyakit" id="riwayat_penyakit" cols="30" rows="4" class="form-control"></textarea>  
                    </div>

                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="riwayat_penyakit_keluarga" class="form-label">Riwayat Penyakit Keluarga</label>
                        <textarea name="riwayat_penyakit_keluarga" id="riwayat_penyakit_keluarga" cols="30" rows="4" class="form-control"></textarea>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="poli" class="form-label">Poli</label>
                        <input type="text"id="poli" class="form-control" value="<?php echo e($antrian->poli->name); ?>" readonly>
                        <input type="hidden" name="poli" value="<?php echo e($antrian->poli->id); ?>">
                    </div>

                    <div class="col-md-6 col-lg-6 col-12">
                        <label for="dokter" class="form-label">Dokter</label>
                        <input type="text"id="dokter" class="form-control" value="<?php echo e($antrian->dokter->user->name); ?>" readonly>
                        <input type="hidden" name="dokter" value="<?php echo e($antrian->dokter->id); ?>">
                    </div>
                </div>

                <div class="mt-3">
                    <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i> Simpan</button> <button class="btn btn-danger" type="reset"><i class="fa fa-times"></i> Batal</button>
                </div>
            </form>
            
            
            <script>
                function formKandungan(){
                    const kandungan = $('#kandungan').val();
                    console.log(kandungan)
                    if(kandungan == 0){
                        $('#form-kandungan').hide();
                    } else{
                        $('#form-kandungan').show();
                    }
                }
            </script>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/rekam-medis/create-from-antrian.blade.php ENDPATH**/ ?>