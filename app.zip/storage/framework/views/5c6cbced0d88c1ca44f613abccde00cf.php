<?php $__env->startSection('dashboard-content'); ?>
<div class="row mt-4">
    <?php if($antrian): ?>
        <div class="menu-item">
            <span class="divider"></span>
            <span class="menu-text">
                Rencana Kunjungan
            </span>
        </div>
        <div class="ml-4 mt-3">
            <div class="row">
                <div class="col-auto">
                    <dl>
                        <dt>No. Antrian</dt>
                        <dd><span class="badge bg-warning"><?php echo e($antrian->no_antrian); ?></span></dd>
                        <dt>Kode Booking</dt>
                        <dd><span class="badge bg-muted"><?php echo e($antrian->kode_booking); ?></span></dd>
                        <dt>Tanggal</dt>
                        <dd><?php echo e(tanggalIndonesia($antrian->tanggal_periksa, true)); ?></dd>
                    </dl>
                </div>

                <div class="col-auto">
                    <dl>
                        <dt>Dokter</dt>
                        <dd><?php echo e($antrian->dokter->user->name); ?></dd>
                        <dt>Poli</dt>
                        <dd><?php echo e($antrian->poli->name); ?></dd>
                        <dt>Status</dt>
                        <dd>
                            <?php if($antrian->status == 'selesai'): ?>
                                <span class="badge bg-success">Selesai</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-uppercase"><?php echo e($antrian->status); ?></span>
                            <?php endif; ?>
                        </dd>
                    </dl>
                </div>
                <hr>
            </div>
        </div>
    <?php endif; ?>

    <div class="menu-item">
        <span class="divider"></span>
        <span class="menu-text">
            Rekam Medis Terbaru <br>
            <span class="badge bg-muted text-uppercase fs-1"><?php echo e($rekamMedis->status); ?></span>
        </span>
    </div>
    <?php if($rekamMedis): ?>
    <div class="row mt-3">
        <div class="col-md-3 col-sm-6 col-12 mb-3">
            <dl>
                <dt>Tanggal Periksa</dt>
                <dd><?php echo e(tanggalIndonesia($rekamMedis->tgl_pemeriksaan, true)); ?></dd>
                <dt>Dokter</dt>
                <dd><?php echo e($rekamMedis->dokter->user->name); ?></dd>
                <dt>Poli</dt>
                <dd><?php echo e($rekamMedis->poli->name); ?></dd>
            </dl>
        </div>
    
        <div class="col-md-3 col-sm-6 col-12 mb-3">
            <dl>
                <dt>Ammanesia/Keluhan(S)</dt>
                <dd><?php echo e($rekamMedis->ammanesia); ?></dd>
                <?php if($rekamMedis->id_rm_kandungan): ?>
                <dt>Riwayat Persalinan</dt>
                <dd>
                    <span class="badge bg-info">G: <?php echo e($rekamMedis->riwayat_persalinan->g); ?></span>
                    <span class="badge bg-info">P: <?php echo e($rekamMedis->riwayat_persalinan->p); ?></span>
                    <span class="badge bg-info">A: <?php echo e($rekamMedis->riwayat_persalinan->a); ?></span>
                </dd>
                <?php endif; ?>
            </dl>
        </div>
    
        <div class="col-md-3 col-sm-6 col-12 mb-3">
            <dl>
                <dt>Pemeriksaan(O)</dt>
                <dd>
                    <?php if($rekamMedis->id_pemeriksaan): ?>
                        <?php echo $rekamMedis->pemeriksaan->deskripsi; ?>

                    <?php else: ?> 
                        -
                    <?php endif; ?>
                </dd>
                <dt>Diagnosa(A)</dt>
                <dd>
                    <?php if($rekamMedis->id_diagnosa): ?>
                        <?php echo $rekamMedis->diagnosa->deskripsi; ?>

                    <?php else: ?> 
                        -
                    <?php endif; ?>
                </dd>
                <dt>Tindakan(P)</dt>
                <dd>
                    <?php if($rekamMedis->id_tindakan): ?>
                        <?php echo $rekamMedis->tindakan->deskripsi; ?>

                    <?php else: ?> 
                        -
                    <?php endif; ?>
                </dd>
            </dl>
        </div>
    
        <div class="col-md-3 col-sm-6 col-12 mb-3">
            <dl>
                <dt>Riwayat Penyakit</dt>
                <dd><?php echo e(($rekamMedis->riwayat_penyakit)?:'-'); ?></dd>
                <dt>Riwayat Penyakit Keluarga</dt>
                <dd><?php echo e(($rekamMedis->riwayat_penyakit_keluarga)?:'-'); ?></dd>
            </dl>
        </div>
    </div>
    
    <?php else: ?> 
    Belum tersedia
    <?php endif; ?>
    <hr>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-pasien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/pasien/dashboard/index.blade.php ENDPATH**/ ?>