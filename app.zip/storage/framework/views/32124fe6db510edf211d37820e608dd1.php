<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <?php if (isset($component)) { $__componentOriginaleaeaaaad569af01bb3cb77043cbff144 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleaeaaaad569af01bb3cb77043cbff144 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tambah-data','data' => ['action' => ''.e(route('admin.petugas.create')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tambah-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('admin.petugas.create')).'']); ?>
        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'name','label' => 'Nama','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'name','label' => 'Nama','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'email','name' => 'email','label' => 'Email','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'email','name' => 'email','label' => 'Email','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'text','name' => 'no_hp','label' => 'No HP','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'no_hp','label' => 'No HP','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'file','name' => 'foto','label' => 'Foto (optional)','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'file','name' => 'foto','label' => 'Foto (optional)','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'role','label' => 'Role','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'role','label' => 'Role','required' => 'true']); ?>
            <option value="admin">Admin</option>
            <option value="doctor">Dokter</option>
            <option value="nurse">Nurse</option>
            <option value="apotek">Apoteker</option>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
        <label for="alamat">Alamat</label>
        <textarea name="alamat" id="alamat" cols="30" rows="3" class="form-control" required></textarea>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleaeaaaad569af01bb3cb77043cbff144)): ?>
<?php $attributes = $__attributesOriginaleaeaaaad569af01bb3cb77043cbff144; ?>
<?php unset($__attributesOriginaleaeaaaad569af01bb3cb77043cbff144); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleaeaaaad569af01bb3cb77043cbff144)): ?>
<?php $component = $__componentOriginaleaeaaaad569af01bb3cb77043cbff144; ?>
<?php unset($__componentOriginaleaeaaaad569af01bb3cb77043cbff144); ?>
<?php endif; ?>
</div>

<?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Data Petugas']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Data Petugas']); ?>
    <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <thead>
            <th>No</th>
            <th>Nama</th>
            <th>Email</th>
            <th>No Hp</th>
            <th>Role</th>
            <th>Foto</th>
            <th>Alamat</th>
            <th></th>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($p->name); ?></td>
                    <td><?php echo e($p->email); ?></td>
                    <td><?php echo e($p->no_hp); ?></td>
                    <td>
                        <?php if($p->role == 'admin'): ?>
                            <span class="badge bg-danger"><?php echo e($p->role); ?></span>
                        <?php elseif($p->role == 'doctor'): ?>
                            <span class="badge bg-success"><?php echo e($p->role); ?></span>
                        <?php elseif($p->role == 'nurse'): ?>
                            <span class="badge bg-primary"><?php echo e($p->role); ?></span>
                        <?php elseif($p->role == 'apotek'): ?>
                            <span class="badge bg-muted"><?php echo e($p->role); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <img src="<?php echo e(asset('img/profil/'.$p->foto)); ?>" class="rounded" width="100px" alt="">
                    </td>
                    <td><?php echo e($p->alamat); ?></td>
                    <td>
                        <?php if (isset($component)) { $__componentOriginal52984d0dc87f31be3fd7055890be5eb4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal52984d0dc87f31be3fd7055890be5eb4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.actions','data' => ['id' => ''.e($p->id).'','routeDelete' => ''.e(route('admin.petugas.delete', encryptStr($p->id))).'','routeEdit' => ''.e(route('admin.petugas.update')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('actions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => ''.e($p->id).'','routeDelete' => ''.e(route('admin.petugas.delete', encryptStr($p->id))).'','routeEdit' => ''.e(route('admin.petugas.update')).'']); ?>
                            <input type="hidden" value="<?php echo e(encryptStr($p->id)); ?>" name="id">
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($p->name).'','type' => 'text','name' => 'name','label' => 'Nama','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($p->name).'','type' => 'text','name' => 'name','label' => 'Nama','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($p->email).'','type' => 'email','name' => 'email','label' => 'Email','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($p->email).'','type' => 'email','name' => 'email','label' => 'Email','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type-value','data' => ['value' => ''.e($p->no_hp).'','type' => 'text','name' => 'no_hp','label' => 'No HP','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type-value'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => ''.e($p->no_hp).'','type' => 'text','name' => 'no_hp','label' => 'No HP','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $attributes = $__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__attributesOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc)): ?>
<?php $component = $__componentOriginalf796955c05cfcbf2b1eeba942d220ccc; ?>
<?php unset($__componentOriginalf796955c05cfcbf2b1eeba942d220ccc); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginala99bc122f8938e60fe55968196477852 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala99bc122f8938e60fe55968196477852 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-type','data' => ['type' => 'file','name' => 'foto','label' => 'Foto (optional)','required' => '']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-type'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'file','name' => 'foto','label' => 'Foto (optional)','required' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $attributes = $__attributesOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__attributesOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala99bc122f8938e60fe55968196477852)): ?>
<?php $component = $__componentOriginala99bc122f8938e60fe55968196477852; ?>
<?php unset($__componentOriginala99bc122f8938e60fe55968196477852); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginaled2cde6083938c436304f332ba96bb7c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaled2cde6083938c436304f332ba96bb7c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.select','data' => ['name' => 'role','label' => 'Role','required' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'role','label' => 'Role','required' => 'true']); ?>
                                <option value="admin" <?php echo e($p->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                <option value="doctor" <?php echo e($p->role == 'doctor' ? 'selected' : ''); ?>>Dokter</option>
                                <option value="nurse" <?php echo e($p->role == 'nurse' ? 'selected' : ''); ?>>Nurse</option>
                                <option value="apotek" <?php echo e($p->role == 'apotek' ? 'selected' : ''); ?>>Apoteker</option>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $attributes = $__attributesOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__attributesOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaled2cde6083938c436304f332ba96bb7c)): ?>
<?php $component = $__componentOriginaled2cde6083938c436304f332ba96bb7c; ?>
<?php unset($__componentOriginaled2cde6083938c436304f332ba96bb7c); ?>
<?php endif; ?>
                            <label for="alamat">Alamat</label>
                            <textarea name="alamat" id="alamat" cols="30" rows="3" class="form-control" required><?php echo e($p->alamat); ?></textarea>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal52984d0dc87f31be3fd7055890be5eb4)): ?>
<?php $attributes = $__attributesOriginal52984d0dc87f31be3fd7055890be5eb4; ?>
<?php unset($__attributesOriginal52984d0dc87f31be3fd7055890be5eb4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal52984d0dc87f31be3fd7055890be5eb4)): ?>
<?php $component = $__componentOriginal52984d0dc87f31be3fd7055890be5eb4; ?>
<?php unset($__componentOriginal52984d0dc87f31be3fd7055890be5eb4); ?>
<?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/petugas/index.blade.php ENDPATH**/ ?>