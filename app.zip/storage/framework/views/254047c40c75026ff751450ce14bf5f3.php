<label for="<?php echo e($name); ?>" class="form-label"><?php echo e($label); ?></label>
<select name="<?php echo e($name); ?>" class="form-select">
    <option value="-" selected disabled>--Pilih--</option>
    <?php echo e($slot); ?>

</select><?php /**PATH /home/stardust/Documents/MY STARTUP/lame pedia/web/resources/views/components/select.blade.php ENDPATH**/ ?>