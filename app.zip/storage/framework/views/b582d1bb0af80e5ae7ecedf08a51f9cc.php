<?php $__env->startSection('content'); ?>
<details class="mb-3">
    <summary>
        Tampilkan detail pasien
    </summary>
    <p>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h4 class="card-title">Detail Pasien</h4>
                            <span class="text-muted">RM# <?php echo e($pasien->no_rm); ?></span>
                        </div>
                        <hr>
                        
                        <!-- Responsive Grid -->
                        <div class="row">
                            <!-- Detail Pasien -->
                            <div class="col-md-4">
                                <h5><i class="fas fa-user"></i> Detail Pasien</h5>
                                <dl>
                                    <dt><i class="fas fa-user"></i> Nama</dt>
                                    <dd><?php echo e($pasien->user->name); ?>, <?php echo e($pasien->gender); ?> (<?php echo e($pasien->status_menikah); ?>)</dd>
                                    <dt><i class="fas fa-calendar-alt"></i> Tempat, Tanggal Lahir</dt>
                                    <dd><?php echo e($pasien->tempat_lahir); ?>, <?php echo e($pasien->tanggal_lahir); ?></dd>
                                    <dt><i class="fas fa-briefcase"></i> Pekerjaan, Pendidikan</dt>
                                    <dd><?php echo e($pasien->pekerjaan); ?>, <?php echo e($pasien->pendidikan); ?></dd>
                                    <dt><i class="fas fa-map-marker-alt"></i> Alamat</dt>
                                    <dd><?php echo e($pasien->alamat); ?></dd>
                                </dl>
                            </div>
                            
                            <!-- Info Pasien -->
                            <div class="col-md-4">
                                <h5><i class="fas fa-info-circle"></i> Info Pasien</h5>
                                <dl>
                                    <dt><i class="fas fa-phone-alt"></i> No HP</dt>
                                    <dd><?php echo e($pasien->no_hp); ?></dd>
                                    <dt><i class="fas fa-id-card"></i> No BPJS/KTP</dt>
                                    <dd><?php echo e($pasien->no_bpjs); ?></dd>
                                    <dt><i class="fas fa-credit-card"></i> Pembayaran</dt>
                                    <dd><?php echo e($pasien->jenis_pembayaran); ?></dd>
                                    <dt><i class="fas fa-exclamation-triangle"></i> Alergi</dt>
                                    <dd><?php echo e($pasien->alergi); ?></dd>
                                </dl>
                            </div>
        
                            <!-- Detail Suami/Istri (Jika Menikah) -->
                            <?php if($pasien->status_menikah == 'menikah'): ?>
                                <div class="col-md-4">
                                    <h5><i class="fas fa-heart"></i> Detail <?php echo e($pasien->gender == 'laki-laki' ? 'Istri' : 'Suami'); ?></h5>
                                    <dl>
                                        <dt><i class="fas fa-user"></i> Nama</dt>
                                        <dd><?php echo e($suamiIstri->nama); ?></dd>
                                        <dt><i class="fas fa-phone-alt"></i> No HP</dt>
                                        <dd><?php echo e($suamiIstri->no_hp); ?></dd>
                                        <dt><i class="fas fa-id-card"></i> No BPJS/KTP</dt>
                                        <dd><?php echo e($suamiIstri->no_bpjs); ?></dd>
                                        <dt><i class="fas fa-calendar-alt"></i> Tempat, Tanggal Lahir</dt>
                                        <dd><?php echo e($suamiIstri->tempat_lahir); ?>, <?php echo e($suamiIstri->tanggal_lahir); ?></dd>
                                        <dt><i class="fas fa-briefcase"></i> Pekerjaan, Pendidikan</dt>
                                        <dd><?php echo e($suamiIstri->pekerjaan); ?>, <?php echo e($suamiIstri->pendidikan); ?></dd>
                                    </dl>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <hr>
    </p>
</details>
<div class="row">
    <div class="col-md-12 col-lg-12 col-12">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">
                    <i class="ti ti-stethoscope fs-6"></i> Rekam Medis Pasien
                </h4>

                <div class="row">
                    <div class="col-md-6 col-lg-6 col-12">
                        <ul>
                            <li>
                                <Strong>Tanggal Pemeriksaan: </Strong>
                                <p>
                                    <?php echo e($rekamMedis->tgl_pemeriksaan); ?>

                                </p>
                            </li>
                            <li>
                                <Strong>Riwayat Persalinan: </Strong>
                                <p>
                                    <?php if($rekamMedis->id_rm_kandungan): ?>
                                    G: <?php echo e($rekamMedis->riwayat_persalinan->g); ?> P: <?php echo e($rekamMedis->riwayat_persalinan->p); ?> A: <?php echo e($rekamMedis->riwayat_persalinan->a); ?>

                                    <?php else: ?> 
                                        -
                                    <?php endif; ?>
                                </p>
                            </li>
                            <li>
                                <strong>Ammanesia: </strong> 
                                <p>
                                    <?php echo e($rekamMedis->ammanesia); ?>

                                </p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-lg-6 col-12">
                        <ul>
                            <li>
                                <strong>Pemeriksaan: </strong> <?php echo ($rekamMedis->id_pemeriksaan) ? $rekamMedis->pemeriksaan->deskripsi : '-'; ?>

                            </li>
                            <li>
                                <strong>Diagnosa: </strong> <?php echo ($rekamMedis->id_diagnosa) ? $rekamMedis->diagnosa->deskripsi : '-'; ?>

                            </li>
                            <li>
                                <strong>Tindakan: </strong> <?php echo ($rekamMedis->id_tindakan) ? $rekamMedis->tindakan->deskripsi : '-'; ?>

                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between">
            <h4 class="card-title">
                <i class="fa fa-pills"></i> Riwayat Obat
            </h4>
        </div>

        <?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <thead>
                <th>Kode</th>
                <th>Nama</th>
                <th>Jumlah</th>
                <th>Harga</th>
                <th>Total</th>
                <th>Ket</th>
            </thead>

            <tbody>
                <?php
                    $total = 0
                ?>
                <?php $__currentLoopData = $riwayatObat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <span class="badge bg-muted"><?php echo e($item->obat->kode); ?></span>
                        </td>
                        <td><?php echo e($item->obat->nama); ?></td>
                        <td><?php echo e($item->jumlah); ?> <?php echo e($item->obat->satuan); ?></td>
                        <td><?php echo e(formatRupiah($item->harga)); ?></td>
                        <td><?php echo e(formatRupiah($item->jumlah * $item->harga)); ?></td>
                        <td><?php echo e($item->keterangan); ?></td>
                    </tr>
                    <?php
                        $total += $item->jumlah * $item->harga
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <td colspan="5" class="text-end">
                    <strong>Total: </strong>
                </td>
                <td id="total-harga" colspan="1"><?php echo e(formatRupiah($total)); ?></td>
            </tfoot>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
    </div>
</div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/admin/obat/riwayat/detail.blade.php ENDPATH**/ ?>