<button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($id); ?>">
    <i class="fa fa-trash"></i>
</button>

<div class="modal fade" id="deleteModal<?php echo e($id); ?>" tabindex="-1" aria-labelledby="deleteModal<?php echo e($id); ?>Label" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h3 class="modal-title fs-5" id="deleteModal<?php echo e($id); ?>Label">Hapus Data</h3>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <strong>Apakah anda Yakin?</strong>
        </div>
        <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">BATAL</button>
        <button type="button" class="btn btn-danger" onclick="event.preventDefault(); document.getElementById('delete<?php echo e($id); ?>').submit();">YA</button>
        </div>
    </div>
    </div>
</div>
<form id="delete<?php echo e($id); ?>" action="<?php echo e($route); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
</form><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/components/delete.blade.php ENDPATH**/ ?>