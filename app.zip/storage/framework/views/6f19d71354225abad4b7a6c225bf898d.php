<?php $__env->startSection('dashboard-content'); ?>
<?php if (isset($component)) { $__componentOriginal163c8ba6efb795223894d5ffef5034f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal163c8ba6efb795223894d5ffef5034f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <thead>
        <th>Pasien</th>
        <th>Antrian</th>
        <th>Tujuan</th>
    </thead>

    <tbody>
        <?php $__currentLoopData = $antrian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <dl>
                        <dt>Nama</dt>
                        <dd><?php echo e($a->pasien->user->name); ?></dd>
                        <dt>No Hp</dt>
                        <dd><?php echo e($a->pasien->user->no_hp); ?></dd>
                        <dt>No BPJS/NIK</dt>
                        <dd><?php echo e($a->pasien->no_bpjs); ?></dd>
                    </dl>
                </td>
                <td>
                    <dl>
                        <dt>Status</dt>
                        <dd><span class="badge text-uppercase bg-<?php echo e(($a->status == 'selesai' ? 'success' : 'warning')); ?>"><?php echo e($a->status); ?></span></dd>
                        <dt>No. Antrian</dt>
                        <dd><span class="badge bg-info"><?php echo e($a->no_antrian); ?></span></dd>
                        <dt>Kode Booking</dt>
                        <dd><span class="badge bg-muted"><?php echo e($a->kode_booking); ?></span></dd>
                    </dl>
                </td>
                <td>
                    <dl>
                        <dt>Poli</dt>
                        <dd><?php echo e($a->poli->name); ?></dd>
                        <dt>Dokter</dt>
                        <dd><?php echo e($a->dokter->user->name); ?></dd>
                    </dl>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $attributes = $__attributesOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__attributesOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal163c8ba6efb795223894d5ffef5034f5)): ?>
<?php $component = $__componentOriginal163c8ba6efb795223894d5ffef5034f5; ?>
<?php unset($__componentOriginal163c8ba6efb795223894d5ffef5034f5); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-pasien', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/stardust/Documents/CLIENT/development/KLIKNIK ANYADELLASIS/web/resources/views/pasien/pendaftaran/index.blade.php ENDPATH**/ ?>