<div class="table-responsive">
    <table class="table table-striped" id="table">
        {{$slot}}
    </table>
</div>