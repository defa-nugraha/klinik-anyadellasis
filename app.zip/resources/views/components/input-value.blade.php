<label for="{{$name}}" class="form-label">{{$label}}</label>
<input type="text" class="form-control" id="{{$name}}" name="{{$name}}" value="{{$value}}" placeholder="{{$label}}">