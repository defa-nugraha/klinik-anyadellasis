<div class="card shadow-lg">
    <div class="card-body">
        <h5 class="card-title fw-semibold mb-4">
            <i class="ti ti-package"></i>
            {{$title}}</h5>
        {{$slot}}
    </div>
</div>