<?php

namespace App\Http\Controllers\dokter;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RekamMedisKandunganDokterController extends Controller
{
    //
}
